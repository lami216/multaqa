# القواعد المختارة من awesome-cursorrules

ضع مجلد `.cursor` في جذر مشروعك.

الملفات المختارة فعلية من الريبو وليست أسماء مقترحة:

1. `nextjs-react-tailwind-cursorrules-prompt-file.mdc`
   - أفضل قاعدة عامة لـ Next.js + React + Tailwind + shadcn/ui + Framer Motion.

2. `cursor-ai-react-typescript-shadcn-ui-cursorrules-p.mdc`
   - مفيد جدًا لتحسين مكونات React/TypeScript مع shadcn/ui.

3. `clean-code.mdc`
   - تنظيف الكود، DRY، أسماء واضحة، single responsibility.

4. `toss-style-design-system.mdc`
   - أقوى ملف لتحسين شكل الواجهة: spacing، typography، cards، colors، dark mode، accessibility.

5. `rtl-right-to-left-i18n-cursorrules-prompt-file.mdc`
   - مهم لو منصتك عربية أو تحتاج RTL.

6. `landing-page-image-quality-cursorrules-prompt-file.mdc`
   - مفيد لو عندك صفحات تسويقية أو صور في الواجهة، يمنع الصور الوهمية والمكسورة.

## لا تبدأ بكل ملفات الريبو
ابدأ بهذه فقط. كثرة القواعد قد تجعل الأيجنت يتضارب أو يبالغ في التعديلات.
